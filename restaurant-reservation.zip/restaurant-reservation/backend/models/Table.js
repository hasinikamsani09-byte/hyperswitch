
const mongoose = require("mongoose");

const tableSchema = new mongoose.Schema({
    tableNumber: {
        type: Number,
        required: true,
        unique: true
    },
    capacity: {
        type: Number,
        required: true
    },
    tableType: {
        type: String,
        enum: ["Regular", "Sofa"],
        default: "Regular"
    },
    status: {
        type: String,
        enum: ["Available", "Reserved", "Occupied", "Unavailable"],
        default: "Available"
    }
});

module.exports = mongoose.model("Table", tableSchema);
