const mongoose = require("mongoose");

const reservationSchema = new mongoose.Schema({
    customerName: {
        type: String,
        required: true,
        trim: true
    },

    phone: {
        type: String,
        required: true
    },

    date: {
        type: String,
        required: true
    },

    time: {
        type: String,
        required: true
    },

    guests: {
        type: Number,
        required: true,
        min: 1
    },

    tableNumber: {
        type: [Number],
        default: []
    },

    status: {
        type: String,
        enum: ["Confirmed", "Cancelled"],
        default: "Confirmed"
    }
});

module.exports = mongoose.model(
    "Reservation",
    reservationSchema
);