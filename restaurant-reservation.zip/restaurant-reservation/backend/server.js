
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const Reservation = require("./models/Reservation");
const Table = require("./models/Table");

const app = express();
const PORT = 5000;
const DB_URL = "mongodb://127.0.0.1:27017/restaurantReservation";
const BOOKING_HOURS = 2;

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
    res.send("Golden Spoon Restaurant Backend is Running!");
});

function bookingsOverlap(date, time, otherDate, otherTime) {
    if (date !== otherDate) return false;

    const start = new Date(`${date}T${time}:00`).getTime();
    const otherStart = new Date(`${otherDate}T${otherTime}:00`).getTime();
    const duration = BOOKING_HOURS * 60 * 60 * 1000;

    if (!Number.isFinite(start) || !Number.isFinite(otherStart)) {
        return false;
    }

    return start < otherStart + duration &&
           start + duration > otherStart;
}

function chooseTables(availableTables, guests) {
    const sorted = [...availableTables].sort(
        (a, b) => b.capacity - a.capacity
    );

    const singleTable = sorted.find(
        table => table.capacity >= guests
    );

    if (singleTable) return [singleTable];

    const selected = [];
    let seats = 0;

    for (const table of sorted) {
        selected.push(table);
        seats += table.capacity;

        if (seats >= guests) return selected;
    }

    return null;
}

async function setupTables() {
    for (let number = 1; number <= 40; number++) {
        let tableType;
        let capacity;

        if (number <= 10) {
            tableType = "Regular";
            capacity = 2;
        } else if (number <= 30) {
            tableType = "Regular";
            capacity = 4;
        } else if (number <= 35) {
            tableType = "Sofa";
            capacity = 4;
        } else {
            tableType = "Sofa";
            capacity = 6;
        }

        await Table.findOneAndUpdate(
            { tableNumber: number },
            {
                $set: { tableType, capacity },
                $setOnInsert: {
                    tableNumber: number,
                    status: "Available"
                }
            },
            { upsert: true, returnDocument: "after" }
        );
    }

    console.log("40 tables are ready: 30 regular + 10 sofa.");
}

// Repair existing records that were saved without status or table numbers.
async function repairOldBookings() {
    const bookings = await Reservation.collection
        .find({})
        .sort({ date: 1, time: 1, _id: 1 })
        .toArray();

    const allTables = await Table.find({
        status: { $ne: "Unavailable" }
    }).lean();

    const processed = [];

    for (const booking of bookings) {
        const status = booking.status || "Confirmed";

        let assigned = Array.isArray(booking.tableNumber)
            ? booking.tableNumber.map(Number).filter(Number.isFinite)
            : booking.tableNumber
                ? [Number(booking.tableNumber)]
                : [];

        if (status === "Confirmed" && assigned.length === 0) {
            const busy = new Set();

            for (const previous of processed) {
                if (
                    previous.status === "Confirmed" &&
                    bookingsOverlap(
                        booking.date,
                        booking.time,
                        previous.date,
                        previous.time
                    )
                ) {
                    previous.tableNumber.forEach(number => busy.add(number));
                }
            }

            const available = allTables.filter(
                table => !busy.has(Number(table.tableNumber))
            );

            const selected = chooseTables(
                available,
                Number(booking.guests)
            );

            assigned = selected
                ? selected.map(table => Number(table.tableNumber))
                : [];

            if (assigned.length === 0) {
                console.warn(
                    `Could not assign tables to booking ${booking._id}`
                );
            }
        }

        // Save the missing fields directly into MongoDB.
        await Reservation.collection.updateOne(
            { _id: booking._id },
            {
                $set: {
                    status,
                    tableNumber: assigned
                }
            }
        );

        processed.push({
            ...booking,
            status,
            tableNumber: assigned
        });
    }

    console.log(`Checked and repaired ${bookings.length} existing bookings.`);
}

app.get("/api/tables", async (req, res) => {
    try {
        const tables = await Table.find().sort({ tableNumber: 1 });
        res.json(tables);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

async function getBusyTableNumbers(date, time) {
    const bookings = await Reservation.collection.find({
        date,
        status: "Confirmed"
    }).toArray();

    const busy = new Set();

    for (const booking of bookings) {
        if (
            bookingsOverlap(date, time, booking.date, booking.time)
        ) {
            const numbers = Array.isArray(booking.tableNumber)
                ? booking.tableNumber
                : booking.tableNumber
                    ? [booking.tableNumber]
                    : [];

            numbers.forEach(number => busy.add(Number(number)));
        }
    }

    return busy;
}

app.post("/api/reservations", async (req, res) => {
    try {
        const { customerName, phone, date, time } = req.body;
        const guests = Number(req.body.guests);

        if (!customerName?.trim() || !phone?.trim() || !date || !time) {
            return res.status(400).json({
                message: "Please fill in all booking fields."
            });
        }

        if (!Number.isInteger(guests) || guests < 1) {
            return res.status(400).json({
                message: "Enter a valid number of guests."
            });
        }

        if (
            !/^\d{4}-\d{2}-\d{2}$/.test(date) ||
            !/^([01]\d|2[0-3]):[0-5]\d$/.test(time)
        ) {
            return res.status(400).json({
                message: "Select a valid date and time."
            });
        }

        const start = new Date(`${date}T${time}:00`);

        if (!Number.isFinite(start.getTime()) || start.getTime() < Date.now()) {
            return res.status(400).json({
                message: "Please select a future date and time."
            });
        }

        const busy = await getBusyTableNumbers(date, time);

        const available = await Table.find({
            status: { $ne: "Unavailable" },
            tableNumber: { $nin: [...busy] }
        }).sort({ tableNumber: 1 }).lean();

        const selected = chooseTables(available, guests);

        if (!selected) {
            return res.status(400).json({
                message: "Not enough tables are available for this booking."
            });
        }

        const assignedNumbers = selected.map(
            table => Number(table.tableNumber)
        );

        const reservation = await Reservation.create({
            customerName: customerName.trim(),
            phone: phone.trim(),
            date,
            time,
            guests,
            tableNumber: assignedNumbers,
            status: "Confirmed"
        });

        res.status(201).json({
            message: "Reservation confirmed successfully!",
            reservation,
            assignedTables: assignedNumbers
        });
    } catch (error) {
        console.error("Booking error:", error);
        res.status(500).json({
            message: "Could not create reservation.",
            error: error.message
        });
    }
});

app.get("/api/reservations", async (req, res) => {
    try {
        const bookings = await Reservation.collection
            .find({})
            .sort({ _id: -1 })
            .toArray();

        res.json(bookings);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Keep the existing Cancel button endpoint working.
app.patch("/api/reservations/:id/cancel", async (req, res) => {
    try {
        if (!mongoose.isValidObjectId(req.params.id)) {
            return res.status(400).json({
                message: "Invalid reservation ID."
            });
        }

        const result = await Reservation.collection.updateOne(
            { _id: new mongoose.Types.ObjectId(req.params.id) },
            { $set: { status: "Cancelled" } }
        );

        if (result.matchedCount === 0) {
            return res.status(404).json({
                message: "Reservation not found."
            });
        }

        res.json({ message: "Reservation cancelled successfully!" });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

app.patch("/api/tables/:tableNumber/status", async (req, res) => {
    try {
        const status = req.body.status;

        if (!["Available", "Unavailable"].includes(status)) {
            return res.status(400).json({
                message: "Status must be Available or Unavailable."
            });
        }

        const table = await Table.findOneAndUpdate(
            { tableNumber: Number(req.params.tableNumber) },
            { $set: { status } },
            { returnDocument: "after" }
        );

        if (!table) {
            return res.status(404).json({ message: "Table not found." });
        }

        res.json({ message: "Table status updated.", table });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

async function startServer() {
    await mongoose.connect(DB_URL);
    console.log("MongoDB Connected Successfully!");

    await setupTables();
    await repairOldBookings();

    app.listen(PORT, () => {
        console.log(`Server running at http://localhost:${PORT}`);
    });
}

startServer().catch(error => {
    console.error("Server startup failed:", error);
    process.exit(1);
});
